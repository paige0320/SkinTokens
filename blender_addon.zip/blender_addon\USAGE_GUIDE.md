# SkinTokens Blender Add-on — Usage Guide & Requirements

Read this before installing or sharing the package. The add-on is a **thin
client**: it only sends a mesh to a local backend and imports the rigged result.
The actual model runs in the backend (`addon_server.py`), which **needs a GPU**.
Handing someone only the add-on `.zip` is not enough — they also need the full
SkinTokens install, the model weights, and a CUDA GPU (or network access to a
backend someone else runs).

## 1. Hardware requirements

| Component | Minimum | Notes |
| --- | --- | --- |
| GPU | **NVIDIA, ≥ 14 GB VRAM, CUDA-capable** | Tested on an RTX 3090 (24 GB, Ampere sm_86). No NVIDIA GPU → the backend cannot run. Apple/AMD/Intel GPUs are **not** supported by the backend. |
| System RAM | 16 GB+ | |
| Disk | ~10 GB free | Model checkpoints ≈ 1.5 GB, Python environment (`.venv`) ≈ 7.5 GB |
| OS | Windows 10/11 (tested) | Linux likely works with the same Python env; macOS can only act as a *client* against a remote backend, never run the model. |

> Ampere cards (RTX 30-series) need the flash-attn → PyTorch SDPA fix that this
> fork ships. See `../WINDOWS_SETUP.md`.

## 2. Software requirements

| Software | Version | Notes |
| --- | --- | --- |
| Blender | **3.6 – 5.1** | Verified working on 4.4 and 5.1. 3.6 is the declared minimum; older (e.g. 3.4) is flagged incompatible. |
| Python | 3.11 | Used by the backend `.venv` (separate from Blender's bundled Python). |
| CUDA Toolkit / driver | 12.1+ | Match the PyTorch build in `requirements`. |

## 3. What a recipient must set up

1. Install the full **SkinTokens** repo and create the `.venv` (see
   `../WINDOWS_SETUP.md` / `../README.md`).
2. Download the model weights: `python download.py --model`.
3. Start the backend: double-click `../run_addon_server.bat`
   (or `.venv\Scripts\python.exe addon_server.py`). Leave it open.
4. Install this add-on in Blender (section 5) and use it (section 6).

## 4. Security rules (please follow)

* The backend binds to **127.0.0.1 only** by default — keep it that way. Do
  **not** set `SKINTOKENS_ADDON_HOST=0.0.0.0` or port-forward it unless you
  fully understand the risk; that exposes your machine on the network.
* Every request is gated by a token auto-written to `~/.skintokens_addon.json`.
  Treat that file (and `.addon_token`) as a secret; never commit them.
* **Do not point your add-on at someone else's backend without their consent**,
  and don't let others point at yours unless you intend to share your GPU.
* Sharing the package is fine — the *code* being public does not let anyone
  connect to your computer. Only a running, network-exposed backend can.

## 5. Installing the add-on

- In Blender: Edit → Preferences → Add-ons → **Install from Disk…** → pick
  `blender_addon.zip` → enable **"SkinTokens Auto-Rig"**.
- Leave its preferences blank — it auto-detects a running local backend. Fill
  in URL/token manually only for a non-default port/host.
- **Each Blender version has its own add-on folder**, so install it once per
  version you use.

## 6. Using it

1. Start the backend (section 3.3) and wait for `... is ready`.
2. Select a mesh object in the viewport (it must show a selection outline).
3. Open the **SkinTokens** tab in the N-panel → click **Rig Selected Mesh**.
4. Blender freezes ~40–50 s while the GPU works, then imports the armature +
   skin weights. The `glTF_not_exported` helper node is removed automatically.

## 7. How to check the add-on version

- **In the file**: `blender_addon/__init__.py` → `bl_info["version"]`.
  Current version: **1.0.0**.
- **In Blender**: Edit → Preferences → Add-ons → expand "SkinTokens Auto-Rig";
  the version is shown next to the name.

## 8. Supported scope (what rigs well)

- ✅ Single characters with a clear skeleton: humanoids, animals, monsters,
  robots — best in a natural T/A-pose.
- ⚠️ Extreme proportions, many limbs/heads, non-natural poses, multiple glued
  characters, or broken meshes → lower quality.
- ❌ Buildings, furniture, plants, props, or whole scenes → not meaningful.
- Input formats: `.obj` / `.fbx` / `.glb` (`.gltf`).
